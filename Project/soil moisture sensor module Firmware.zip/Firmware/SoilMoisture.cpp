#include "SoilMoisture.h"

SoilMoisture::SoilMoisture(int pin) : AnalogReader(pin) {}

